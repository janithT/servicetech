<section class="section hero is-fullheight is-error-section">
    <div class="hero-body">
        <div class="container">
            <div class="columns is-centered">
                <div class="column is-two-fifths">
                    {!! $slot !!}
                </div>
            </div>
        </div>
    </div>
    <div class="hero-foot has-text-centered">
        <div class="logo"></div>
    </div>
</section>