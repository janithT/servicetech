<section class="section hero is-fullheight is-error-section">
    <div class="hero-body">
        <div class="container">
            <div class="columns is-centered">
                <div class="column is-two-fifths">
                    <?php echo $slot; ?>

                </div>
            </div>
        </div>
    </div>
    <div class="hero-foot has-text-centered">
        <div class="logo"></div>
    </div>
</section><?php /**PATH E:\servicetech\resources\views/components/full-page-section.blade.php ENDPATH**/ ?>